<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('default.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<?php echo $__env->yieldContent('content'); ?>


<?php /**PATH C:\OSPanel\OSPanel\domains\design\resources\views/layouts/app.blade.php ENDPATH**/ ?>