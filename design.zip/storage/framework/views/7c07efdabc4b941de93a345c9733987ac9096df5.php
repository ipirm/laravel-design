<?php $__env->startSection('pageTitle','Главная'); ?>
<?php $__env->startSection('content'); ?>
    <body class="home">
    <a class="js-bg">
    </a>
    <nav class="nav hide">
        <div class="nav-container">
            <div class="wrapper">
                <div class="top_info">
                    <div class="nav-item">
                        <p class="nav-item_name" id="contact-1"><?php echo e($setting->telegram); ?></p>
                        <div class="nav-item_social">Telegram <?php echo e($setting->click); ?></div>
                    </div>
                    <div class="nav-item">
                        <p class="nav-item_name" id="contact-2"><?php echo e($setting->jabber); ?></p>
                        <div class="nav-item_social">Jabber</div>
                    </div>
                    <div class="nav-item">
                        <p class="nav-item_name" id="contact-3"><?php echo e($setting->vip_pole); ?></p>
                        <div class="nav-item_social">VIPole</div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <main>
        <div class="top_block">
            <div class="wrapper">
                <div class="btn-contact">Контакты</div>
                <section class="text">
                    <div class="text-title"><?php echo e($setting->title); ?></div>
                    <div class="text-description"><?php echo $setting->text; ?></div>
                </section>
            </div>
        </div>
        <div class="wrapper bottom_content">
            <section class="card">
                <div class="card-row">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-col">
                            <a class="card-item" href="/project/<?php echo e($item->id); ?>">
                                <img src="/storage/<?php echo e($item->main_image); ?>" alt="photo" class="card-img">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        </div>
    </main>
    <style>
        .js-bg {
            background-image: url('/storage/<?php echo e($setting->desktop_image); ?>') !important;
        }

        @media (max-width: 992px) {
            .js-bg {
                background: url('/storage/<?php echo e($setting->tablet_image); ?>') !important;
            }
        }

        @media (max-width: 576px) {
            .js-bg {
                background: url('/storage/<?php echo e($setting->mobile_image); ?>') !important;
            }
        }
    </style>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
        $(document).ready(function () {

            $('.btn-contact').on('click', function () {
                if ($('.hide').hasClass('open')) {
                    $('.hide').removeClass('open');
                } else {
                    $('.hide').addClass('open');
                }
            });

            function selectText(elementId) {

                var doc = document,
                    text = doc.getElementById(elementId), range, selection;

                if (doc.body.createTextRange) {

                    range = document.body.createTextRange();
                    range.moveToElementText(text);
                    range.select();

                } else if (window.getSelection) {

                    selection = window.getSelection();
                    range = document.createRange();
                    range.selectNodeContents(text);
                    selection.removeAllRanges();
                    selection.addRange(range);

                }

            }

            $(".nav-item_name").click(function () {

                selectText(this.id);
                document.execCommand("copy");

            });
            document.querySelector('.js-bg').onclick = () => {
                $.ajax({
                    url: '/click',
                    type: 'POST',
                    success: function success() {
                        window.location.href= '<?php echo e($setting->link); ?>'
                    }
                });
            }
        });
    </script>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\OSPanel\domains\design\resources\views/index.blade.php ENDPATH**/ ?>