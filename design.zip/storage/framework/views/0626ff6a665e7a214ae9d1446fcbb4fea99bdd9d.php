<?php $__env->startSection('content'); ?>
<body class="home">
<nav class="nav hide">
    <div class="nav-container">
        <div class="wrapper">
            <div class="top_info">
                <div class="nav-item">
                    <p class="nav-item_name" id="contact-1">@gurguru</p>
                    <div class="nav-item_social">Telegram</div>
                </div>
                <div class="nav-item">
                    <p class="nav-item_name" id="contact-2">great-guru@xmpp.jp</p>
                    <div class="nav-item_social">Jabber</div>
                </div>
                <div class="nav-item">
                    <p class="nav-item_name" id="contact-3">great_guru</p>
                    <div class="nav-item_social">VIPole</div>
                </div>
            </div>
        </div>
    </div>
</nav>
<main>
    <div class="top_block">
        <div class="wrapper">
            <div class="btn-contact">Контакты</div>
            <section class="text">
                <div class="text-title">гуру дизайна</div>
                <div class="text-description"><strong>«Ничего лишнего»</strong> - то, чем руководствуется наша команда.<br>
                    Соберем красочный образ вашего бизнеса, продукта или задумки,<br>
                    учитывая все пожелания и сильные стороны.</div>
            </section>
        </div>
    </div>
    <div class="wrapper bottom_content">
        <section class="card">
            <div class="card-row">
                <div class="card-col">
                    <a class="card-item" href="page.html">
                        <img src="img/photo.jpg" alt="photo" class="card-img">
                    </a>
                </div>
                <div class="card-col">
                    <div class="card-item">
                        <a href="page.html">
                            <img src="img/photo.jpg" alt="photo" class="card-img">
                        </a>
                    </div>
                </div>
                <div class="card-col">
                    <div class="card-item">
                        <a href="page.html">
                            <img src="img/photo.jpg" alt="photo" class="card-img">
                        </a>
                    </div>
                </div>
                <div class="card-col">
                    <div class="card-item">
                        <a href="page.html">
                            <img src="img/photo.jpg" alt="photo" class="card-img">
                        </a>
                    </div>
                </div>
                <div class="card-col">
                    <div class="card-item">
                        <a href="page.html">
                            <img src="img/photo.jpg" alt="photo" class="card-img">
                        </a>
                    </div>
                </div>
                <div class="card-col">
                    <div class="card-item">
                        <a href="page.html">
                            <img src="img/photo.jpg" alt="photo" class="card-img">
                        </a>
                    </div>
                </div>
                <div class="card-col">
                    <div class="card-item">
                        <a href="page.html">
                            <img src="img/photo.jpg" alt="photo" class="card-img">
                        </a>
                    </div>
                </div>
                <div class="card-col">
                    <div class="card-item">
                        <a href="page.html">
                            <img src="img/photo.jpg" alt="photo" class="card-img">
                        </a>
                    </div>
                </div>
                <div class="card-col">
                    <div class="card-item">
                        <a href="page.html">
                            <img src="img/photo.jpg" alt="photo" class="card-img">
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </div>
</main>
<script>
    $( document ).ready(function() {

        $('.btn-contact').on('click', function(){
            if($('.hide').hasClass('open')) {
                $('.hide').removeClass('open');
            }
            else {
                $('.hide').addClass('open');
            }
        });

        function selectText(elementId) {

            var doc = document,
                text = doc.getElementById(elementId), range, selection;

            if(doc.body.createTextRange) {

                range = document.body.createTextRange();
                range.moveToElementText(text);
                range.select();

            } else if(window.getSelection) {

                selection = window.getSelection();
                range = document.createRange();
                range.selectNodeContents(text);
                selection.removeAllRanges();
                selection.addRange(range);

            }

        }

        $(".nav-item_name").click(function() {

            selectText(this.id);
            document.execCommand("copy");

        });

    });
</script>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\OSPanel\domains\design\resources\views/welcome.blade.php ENDPATH**/ ?>