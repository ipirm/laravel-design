<?php return array (
  'cloudstudio/card-extended' => 
  array (
    'providers' => 
    array (
      0 => 'Cloudstudio\\CardExtended\\CardServiceProvider',
    ),
  ),
  'coderello/laravel-nova-lang' => 
  array (
    'providers' => 
    array (
      0 => 'Coderello\\LaravelNovaLang\\Providers\\LaravelNovaLangServiceProvider',
    ),
  ),
  'daniel-de-wit/nova-single-record-resource' => 
  array (
    'providers' => 
    array (
      0 => 'DanielDeWit\\NovaSingleRecordResource\\Providers\\NovaSingleRecordResourceServiceProvider',
    ),
  ),
  'energon7/nova' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Nova\\NovaCoreServiceProvider',
    ),
    'aliases' => 
    array (
      'Nova' => 'Laravel\\Nova\\Nova',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'halimtuhu/array-images' => 
  array (
    'providers' => 
    array (
      0 => 'Halimtuhu\\ArrayImages\\FieldServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
);