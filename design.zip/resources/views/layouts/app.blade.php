<!DOCTYPE html>
<html lang="{{app()->getLocale()}}">
<head>
    @include('default.head')
</head>

@yield('content')


